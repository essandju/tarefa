async function loadProjects(){
  const grid=document.getElementById('projects-grid');
  try{
    let projects;
    try { const response=await fetch('projectos.json'); if(!response.ok)throw new Error(''); projects=await response.json(); }
    catch { projects=[{title:'O meu primeiro projecto',description:'Uma breve descrição do que este projecto faz e das tecnologias que usei.',category:'HTML + CSS',file:'projetos/exemplo.html',symbol:'01'}]; }
    document.getElementById('project-count').textContent=`${String(projects.length).padStart(2,'0')} PROJECTO${projects.length===1?'':'S'}`;
    document.getElementById('empty-message').hidden=projects.length>0;
    projects.forEach((project,index)=>{
      const card=document.createElement('article');card.className='project-card';
      const art=document.createElement('div');art.className='card-art';
      const symbol=document.createElement('span');symbol.className='art-symbol';symbol.textContent=project.symbol||'&lt;/&gt;';art.append(symbol);
      const body=document.createElement('div');body.className='card-body';
      const meta=document.createElement('div');meta.className='card-meta';
      const tag=document.createElement('span');tag.className='tag';tag.textContent=project.category||'HTML';
      const number=document.createElement('span');number.className='card-number';number.textContent=String(index+1).padStart(2,'0');meta.append(tag,number);
      const title=document.createElement('h3');title.textContent=project.title;
      const description=document.createElement('p');description.textContent=project.description;
      const actions=document.createElement('div');actions.className='card-actions';
      const preview=document.createElement('button');preview.className='preview-button';preview.textContent='Pré-visualizar';preview.addEventListener('click',()=>showPreview(project));
      const open=document.createElement('a');open.className='open-link';open.href=project.file;open.target='_blank';open.rel='noreferrer';open.textContent='Abrir projecto ↗';
      actions.append(preview,open);body.append(meta,title,description,actions);card.append(art,body);grid.append(card);
    });
  }catch(error){document.getElementById('empty-message').hidden=false;document.getElementById('empty-message').textContent='Não foi possível ler projectos.json. Confirma se o ficheiro existe e contém uma lista JSON válida.';}
}
function showPreview(project){document.getElementById('preview-title').textContent=project.title;document.getElementById('preview-frame').src=project.file;document.getElementById('preview-dialog').showModal();}
document.getElementById('close-preview').addEventListener('click',()=>{document.getElementById('preview-dialog').close();document.getElementById('preview-frame').src='about:blank';});
document.getElementById('preview-dialog').addEventListener('click',event=>{if(event.target===event.currentTarget)event.currentTarget.close();});
loadProjects();

